



document.addEventListener("DOMContentLoaded",function(){
    document.querySelector(".manu-close-open").addEventListener("click",function(){

        document.querySelector(".mobile-menu").style.width="100%";
    });

    document.querySelector(".menu-close-btn").addEventListener("click",function(){

        document.querySelector(".mobile-menu").style.width="0";
    });

 
    document.querySelector(".search-icon").addEventListener("click",function(){

        document.querySelector(".search-drower").style.width="50%";
    });
     
    
    document.querySelector(".drower-close").addEventListener("click",function(){

        document.querySelector(".search-drower").style.width="0";
    });



});


window.addEventListener('scroll',function(){
   
    if (window.scrollY > 100) {

            document.querySelector("header").style.
            cssText = "position:sticky;top:0; background-color:red;"
 
      }

      else{
        document.querySelector("header").style.
        cssText = " position: absolute;  background-color:transparent; top: 0;left: 0;right: 0;"
        
      }

     
})